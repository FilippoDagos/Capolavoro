<?php
$warn = "";
$form = false;
$result = "";
if(isset($_POST['invia'])){
if(empty($_POST['firstname']) OR empty($_POST['lastname']) OR empty($_POST['subject'])){
$warn = "Inserire tutti i valori!";
}else{
$nome = $_POST['firstname'];
$cognome = $_POST['lastname'];
$materia = $_POST['subject'];
$result = "La materia preferita di " . $nome . " " . $cognome . " e' " . $materia;

$form = true;
}
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <title>Esercizio Materia Preferita</title>
</head>
<body>
    <div class="container">
        <form action="" method="POST">
    <input placeholder="Nome" type="text" name="firstname">
    <input placeholder="Cognome" type="text" name="lastname">
    <p></p>
    <h2>Materia Preferita:</h2>
    <input type="radio" id="materia1" name="subject" value="Informatica" />
      <label for="materia1">Informatica</label>
<br>
      <input type="radio" id="materia2" name="subject" value="Sistemi e reti" />
      <label for="materia2">Sistemi e reti</label>
<br>
      <input type="radio" id="materia3" name="subject" value="Tpsit" />
      <label for="materia3">Tpsit</label>
      <br>
      <p class="warn"><?php echo $warn; ?><p>
      <input value="Invia" class="btn" name="invia" type="submit">
      </div>
      </form>
      <div class="container">
        <table class="data-table">
            <caption>Dati inseriti nel form</caption>
            <thead>
                <tr>
                    
                        <th>Nome</th>
                        <th>Cognome</th>
                        <th>Materia</th>
                    
                </tr>
            </thead>
            <tbody>
                <tr>
                <?php
                    if($form){
                        ?>
                <td><?php echo $nome; ?></td>
                <td><?php echo $cognome; ?></td>
                <td><?php echo $materia; ?></td>
<?php 
                    }
                    ?>
                </tr>
        </tbody>
        </table>
        <table class="data-table">
            <caption>Output prodotto dal server</caption>
            <thead>
                <tr>
                    <th>Output</th>
                </tr>
            </thead>
            <tbody>
            <tr>
                <td><?php echo $result; ?></td>
            </tr>
        </tbody>
        </table>
    </div>
</body>
</html>


<style>
    .container {
    margin: 20px;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 300px;
}

.btn{
margin-top: 24px;
    background-color: #007bff;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}
.warn{
color: red;
}

input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

.radio-group {
    margin-bottom: 20px;
}

input[type="radio"] {
    margin-right: 10px;
    margin-bottom: 5px;
}

label {
    font-size: 16px;
}


.container {
    margin: 20px;
    padding: 20px;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.data-table caption {
    font-weight: bold;
    font-size: 18px;
    margin-bottom: 10px;
}

.data-table th, .data-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.data-table th {
    background-color: #007bff;
    color: #fff;
}

.data-table tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}


</style>